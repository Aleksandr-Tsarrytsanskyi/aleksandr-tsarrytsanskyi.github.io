const FormValidator = (() => {
    const rules = {
        required: value => value.length > 0 || 'Обязательное поле',
        email: value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || 'Некорректный email',
        min: (value, limit) => Array.from(value).length >= limit || `Минимум символов — ${limit}`,
        max: (value, limit) => Array.from(value).length <= limit || `Максимум символов — ${limit}`
    };
    const rulesCache = new WeakMap();

    function getRules(field) {
        if (!rulesCache.has(field)) {
            const parsed = (field.dataset.rules || '').split('|').map(rule => {
                const [name, limit] = rule.split(':');
                return { name, limit: Number(limit) };
            }).filter(({ name }) => Object.hasOwn(rules, name));

            rulesCache.set(field, parsed);
        }

        return rulesCache.get(field);
    }

    function setFieldState(field, message = '', validated = true) {
        field.classList.toggle('is-invalid', Boolean(message));
        field.classList.toggle('is-valid', validated && !message);

        if (validated) {
            field.setAttribute('aria-invalid', String(Boolean(message)));
        } else {
            field.removeAttribute('aria-invalid');
        }

        const error = field.closest('.form-group')?.querySelector('.error');
        if (error) {
            error.textContent = message;
        }
    }

    function validateField(field) {
        const value = field.value.trim();

        for (const { name, limit } of getRules(field)) {
            if (value === '' && name !== 'required') {
                continue;
            }

            const result = rules[name](value, limit);
            if (result !== true) {
                setFieldState(field, result);
                return false;
            }
        }

        setFieldState(field);
        return true;
    }

    function validateForm(form) {
        let firstInvalid;

        for (const field of form.querySelectorAll('[data-rules]')) {
            if (!validateField(field)) {
                firstInvalid ??= field;
            }
        }

        firstInvalid?.focus();
        return !firstInvalid;
    }

    function init(form) {
        const status = form.querySelector('.form-response');
        const buttons = [...form.querySelectorAll('[type="submit"]:enabled')];
        let isSubmitting = false;

        form.addEventListener('focusout', event => {
            if (event.target.matches('[data-rules]')) {
                validateField(event.target);
            }
        });

        form.addEventListener('input', event => {
            if (event.target.matches('[data-rules][aria-invalid]')) {
                validateField(event.target);
            }
        });

        form.addEventListener('submit', async event => {
            event.preventDefault();

            if (isSubmitting) {
                return;
            }

            status.textContent = '';

            if (!validateForm(form)) {
                return;
            }

            const body = new FormData(form);
            isSubmitting = true;
            buttons.forEach(button => { button.disabled = true; });
            status.textContent = 'Отправляем заявку…';

            try {
                const response = await fetch(form.action, { method: 'POST', body });
                const data = await response.json();

                if (response.status === 422 && data.errors) {
                    let firstInvalid;

                    for (const [name, message] of Object.entries(data.errors)) {
                        const field = form.elements.namedItem(name);
                        if (field instanceof HTMLElement) {
                            setFieldState(field, message);
                            firstInvalid ??= field;
                        }
                    }

                    status.textContent = 'Проверьте выделенные поля.';
                    firstInvalid?.focus();
                    return;
                }

                if (!response.ok || data.success !== true) {
                    status.textContent = data.message || 'Не удалось отправить заявку. Попробуйте позже.';
                    return;
                }

                form.reset();
                form.querySelectorAll('[data-rules], [aria-invalid]').forEach(field => {
                    setFieldState(field, '', false);
                });

                status.textContent = data.message || 'Заявка принята. Спасибо!';
            } catch {
                status.textContent = 'Не удалось получить ответ сервера. Попробуйте позже.';
            } finally {
                isSubmitting = false;
                buttons.forEach(button => { button.disabled = false; });
            }
        });
    }

    return { init, validateForm, validateField };
})();

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('form[data-contact-form]').forEach(FormValidator.init);
});
