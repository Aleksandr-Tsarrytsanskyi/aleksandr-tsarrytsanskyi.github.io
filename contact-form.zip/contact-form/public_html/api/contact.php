<?php

declare(strict_types=1);

use Dotenv\Dotenv;
use PHPMailer\PHPMailer\PHPMailer;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function writeResponse(int $status, array $data): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}

function respond(int $status, array $data): never
{
    writeResponse($status, $data);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(405, ['success' => false, 'message' => 'Метод запроса не поддерживается.']);
}

$fields = [
    'name' => ['Имя', 2, 50, 'Введите имя'],
    'email' => ['Email', 1, 254, 'Введите email'],
    'city' => ['Город', 3, 100, 'Введите город'],
    'district' => ['Район', 0, 100, ''],
    'message' => ['Сообщение', 0, 2000, ''],
];

$data = [];
$errors = [];

foreach ($fields as $name => [$label, $min, $max, $requiredMessage]) {
    $raw = $_POST[$name] ?? '';

    if (!is_string($raw) || !mb_check_encoding($raw, 'UTF-8') || str_contains($raw, "\0")) {
        $errors[$name] = 'Некорректное значение';
        continue;
    }

    $value = trim($raw);
    $data[$name] = $value;
    $length = mb_strlen($value, 'UTF-8');

    if ($value === '' && $min > 0) {
        $errors[$name] = $requiredMessage;
    } elseif ($length < $min || $length > $max) {
        $errors[$name] = $length < $min ? "Минимум символов — $min" : "Максимум символов — $max";
    } elseif ($name === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
        $errors[$name] = 'Некорректный email';
    }
}

if ($errors !== []) {
    respond(422, ['success' => false, 'errors' => $errors]);
}

try {
    require_once dirname(__DIR__) . '/vendor/autoload.php';

    $environment = Dotenv::createImmutable(dirname(__DIR__, 2));
    $environment->load();
    $environment->required([
        'SMTP_HOST', 'SMTP_PORT', 'SMTP_ENCRYPTION', 'SMTP_USERNAME',
        'SMTP_PASSWORD', 'MAIL_TO', 'TELEGRAM_BOT_TOKEN', 'TELEGRAM_CHAT_ID',
    ])->notEmpty();

    $environment->required('SMTP_PORT')->isInteger();
    $environment->required('SMTP_ENCRYPTION')->allowedValues(['tls', 'ssl']);

    $smtpPort = (int) $_ENV['SMTP_PORT'];

    if (
        $smtpPort < 1 || $smtpPort > 65535 ||
        !filter_var($_ENV['SMTP_USERNAME'], FILTER_VALIDATE_EMAIL) ||
        !filter_var($_ENV['MAIL_TO'], FILTER_VALIDATE_EMAIL) ||
        !preg_match('/^\d+:[A-Za-z0-9_-]+$/D', $_ENV['TELEGRAM_BOT_TOKEN'])
    ) {
        throw new RuntimeException('Invalid settings.');
    }
} catch (Throwable) {
    error_log('Contact form: failed to load or validate configuration.');
    respond(500, ['success' => false, 'message' => 'Форма временно недоступна.']);
}

$subject = 'Новая заявка с сайта';
$lines = [$subject, ''];

foreach ($fields as $name => [$label]) {
    if ($data[$name] !== '') {
        $lines[] = "$label: " . $data[$name];
    }
}

$text = implode("\n", $lines);

$finishRequest = match (true) {
    function_exists('fastcgi_finish_request') => 'fastcgi_finish_request',
    function_exists('litespeed_finish_request') => 'litespeed_finish_request',
    default => null,
};

if ($finishRequest !== null) {
    ignore_user_abort(true);
    writeResponse(202, ['success' => true, 'message' => 'Заявка принята. Спасибо!']);
    $finishRequest();
}

$emailSent = false;
$telegramSent = false;

try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = $_ENV['SMTP_HOST'];
    $mail->Port = $smtpPort;
    $mail->SMTPAuth = true;
    $mail->Username = $_ENV['SMTP_USERNAME'];
    $mail->Password = $_ENV['SMTP_PASSWORD'];
    $mail->SMTPSecure = $_ENV['SMTP_ENCRYPTION'];
    $mail->Timeout = 8;
    $mail->CharSet = PHPMailer::CHARSET_UTF8;
    $mail->setFrom($_ENV['SMTP_USERNAME'], 'Форма сайта');
    $mail->addAddress($_ENV['MAIL_TO']);
    $mail->addReplyTo($data['email']);
    $mail->Subject = $subject;
    $mail->Body = $text;
    $emailSent = $mail->send();
} catch (Throwable) {
    error_log('Contact form: SMTP delivery failed.');
}

try {
    $url = 'https://api.telegram.org/bot' . $_ENV['TELEGRAM_BOT_TOKEN'] . '/sendMessage';
    $curl = curl_init($url);

    if ($curl === false) {
        throw new RuntimeException('Could not initialize cURL.');
    }

    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'chat_id' => $_ENV['TELEGRAM_CHAT_ID'],
            'text' => $text,
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 6,
    ]);

    $result = curl_exec($curl);
    $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $response = is_string($result) ? json_decode($result, true) : null;
    $telegramSent = $status === 200 && ($response['ok'] ?? false) === true;

    if (!$telegramSent) {
        error_log(sprintf('Contact form: Telegram HTTP %d, cURL %d.', $status, curl_errno($curl)));
    }

    unset($curl);
} catch (Throwable) {
    error_log('Contact form: Telegram request failed.');
}

if ($finishRequest !== null) {
    exit;
}

if (!$emailSent && !$telegramSent) {
    respond(502, ['success' => false, 'message' => 'Не удалось отправить заявку. Попробуйте позже.']);
}

respond(200, ['success' => true, 'message' => 'Заявка отправлена. Спасибо!']);
